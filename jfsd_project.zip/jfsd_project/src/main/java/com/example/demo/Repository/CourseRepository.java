package com.example.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.Courses;
import java.util.List;
import java.util.Optional;


public interface CourseRepository extends JpaRepository<Courses, Long>{
	
	public Courses findByTitle(String title);

}
