package com.example.demo.DAO;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.Repository.CourseRepository;
import com.example.demo.model.Courses;

@Component
public class CourseDAO {
	
	@Autowired
	CourseRepository repo;
	
	public Courses addCourse(Courses courses)
	{
		repo.save(courses);
		return courses;
	}
	
	public Courses findCourse(String title)
	{
		return repo.findByTitle(title);
	}
	public List<Courses> getall()
	{
		return repo.findAll();
	}
	public void DeleteCourse(String title)
	{
		repo.delete(findCourse(title));
	}
	
	public void updateCourse(String title)
	{
		Courses course=findCourse(title);
		DeleteCourse(title);
		repo.save(course);
	}
}
